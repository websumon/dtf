<?php
/**
 * Report Reviews
 *
 * @package Report
 */

use TUTOR_REPORT\PageController;

$page_ctrl = new PageController();
$page_ctrl->handle_review_page();
?>